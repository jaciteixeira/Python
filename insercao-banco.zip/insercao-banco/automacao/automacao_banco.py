import cx_Oracle
import pandas as pd

login = "rm99627"
pswd = "051298"

print('Apontando biblioteca Oracle...')
cx_Oracle.init_oracle_client(lib_dir=r"C:\Users\logonrmlocal\Downloads\CRUD\instantclient_21_11")
print('...feito!\n')

print('Criando DSN...')
dsn = cx_Oracle.makedsn(host="oracle.fiap.com.br", port=1521, sid="orcl")
print('...DSN criado!\n')

print('abrindo conexão')
conn = cx_Oracle.connect(user=login, password=pswd, dsn=dsn)
print('...conexão estabelecida!\n')

# Criando cursor
print('Criando cursor...')
cursor = conn.cursor()
print('...cursor criado!\n')

create_table = """
DECLARE
  table_exists NUMBER;
BEGIN

  SELECT COUNT(*)
  INTO table_exists
  FROM user_tables
  WHERE table_name = 'HEART_ATTACK';

  IF table_exists = 0 THEN
    EXECUTE IMMEDIATE 
    'CREATE TABLE HEART_ATTACK (
    ID VARCHAR2(7) PRIMARY KEY,
    IDADE NUMBER, 
    SEXO VARCHAR2(10), 
    COLESTEROL NUMBER, 
    PRESSAO_SANGUINEA VARCHAR2(10), 
    FREQUENCIA_CARDIACA NUMBER, 
    DIABETES NUMBER, 
    HISTORICO_FAMILIAR NUMBER, 
    TABAGISMO NUMBER, 
    OBESIDADE NUMBER, 
    CONSUMO_ALCOOL NUMBER,
    HORAS_EXERCICIO_SEMANA NUMBER,
    DIETA VARCHAR2(50),
    PROBLEMAS_CARDIACOS_ANTERIORES NUMBER, 
    USO_MEDICAMENTO NUMBER,
    NIVEL_ESTRESSE VARCHAR2(20),
    HORAS_SEDENTARIAS_DIARIAS NUMBER,
    RENDA NUMBER,
    IMC NUMBER,
    TRIGLICERIDEOS NUMBER, 
    DIAS_ATIVIDADE_FISICA_SEMANA NUMBER,
    HORAS_SONO_DIARIAS NUMBER,
    PAIS VARCHAR2(50),
    CONTINENTE VARCHAR2(20),
    HEMISFERIO VARCHAR2(20),
    RISCO_INFARTO VARCHAR2(20)
    )';
  END IF;
END;

"""
cursor.execute(create_table)

# Lê o CSV para um DataFrame do Pandas
heart_attack = pd.read_csv('heart_attack_prediction_dataset.csv', sep=',')
first_5_rows = heart_attack.head(5)

# Itera sobre as linhas do DataFrame e insere os dados no Oracle
for _, row in heart_attack.iterrows():
    insert_query = """
    INSERT INTO HEART_ATTACK (
        ID, IDADE, SEXO, COLESTEROL, PRESSAO_SANGUINEA, FREQUENCIA_CARDIACA,
        DIABETES, HISTORICO_FAMILIAR, TABAGISMO, OBESIDADE, CONSUMO_ALCOOL,
        HORAS_EXERCICIO_SEMANA, DIETA, PROBLEMAS_CARDIACOS_ANTERIORES,
        USO_MEDICAMENTO, NIVEL_ESTRESSE, HORAS_SEDENTARIAS_DIARIAS, RENDA,
        IMC, TRIGLICERIDEOS, DIAS_ATIVIDADE_FISICA_SEMANA,
        HORAS_SONO_DIARIAS, PAIS, CONTINENTE, HEMISFERIO, RISCO_INFARTO
    ) VALUES (
        :1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11, :12, :13, :14, :15, :16,
        :17, :18, :19, :20, :21, :22, :23, :24, :25, :26
    )
    """
    try:
        cursor.execute(insert_query, (
            row['Patient ID'], row['Age'], row['Sex'], row['Cholesterol'], row['Blood Pressure'],
            row['Heart Rate'], row['Diabetes'], row['Family History'], row['Smoking'],
            row['Obesity'], row['Alcohol Consumption'], row['Exercise Hours Per Week'],
            row['Diet'], row['Previous Heart Problems'], row['Medication Use'],
            row['Stress Level'], row['Sedentary Hours Per Day'], row['Income'],
            row['BMI'], row['Triglycerides'], row['Physical Activity Days Per Week'],
            row['Sleep Hours Per Day'], row['Country'], row['Continent'],
            row['Hemisphere'], row['Heart Attack Risk']
        ))
        print(f'Adicionando {row["Patient ID"]} ao banco de dados.')

    except Exception as e:
        print(f"Erro ao inserir linha: {e}")
        print(f"Dados da linha: {row}")

# Commit das alterações
conn.commit()

print('Encerrando cursor...')
cursor.close()
print('...cursor encerrada!\n')

